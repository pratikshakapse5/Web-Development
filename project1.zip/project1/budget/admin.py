from django.contrib import admin
from budget.models import Budget
# Register your models here.

admin.site.register(Budget)
