from django.contrib import admin
from core.models import UserProfileCore

# Register your models here.
admin.site.register(UserProfileCore)